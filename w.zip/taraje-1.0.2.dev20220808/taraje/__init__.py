"""
    :Author: ampasmanusa (bancetzLaut) <0.ampasmanusa@gmail.com>
    :Created: 2022-03-19T23:30:18+07:00
    :Updated: 2022-06-09T14:39:04+07:00
    :Version: 1.0.2.dev20220808
    :Description: Taraje's Bot Loader.

    ..NOTE:: Previous `loader` ended up in v0.3.0.
             Starting from v1.0.0, the configuration file uses `*.lua`.

    """
